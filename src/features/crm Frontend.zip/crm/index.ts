// Pages
export { CrmPipelinesPage } from './pages/CrmPipelinesPage';
export { CalendarioPage } from './pages/CalendarioPage';
export { IntegracionesPage } from './pages/IntegracionesPage';
// Modelo profesional: Contactos y Oportunidades
export { ContactosPage } from './pages/ContactosPage';
export { OportunidadesPage } from './pages/OportunidadesPage';
export { ContactoDetailPage } from './pages/ContactoDetailPage';
export { OportunidadDetallePage } from './pages/OportunidadDetallePage';

// Components
export { EtapaModal } from './components/EtapaModal';
export { ActividadFormModal } from './components/ActividadFormModal';
export { ActividadDetallesModal } from './components/ActividadDetallesModal';
export { PipelineModal } from './components/PipelineModal';

// API
export * from './api/crmApi';

// Types
export * from './types/crm.types';
